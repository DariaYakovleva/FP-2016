{-# OPTIONS_GHC -fno-warn-tabs #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE UndecidableInstances #-}
{-# LANGUAGE MultiParamTypeClasses #-}
module Tree2
       ( Tree.Tree (..)
       , Tree.directoryPrint
       , Tree.verticalPrint
       ) where

import qualified MyTree as Tree

main = do 
	print $ "d"
	print $ mconcat [t1, t2, t3]
	print $ t4
	print $ toList t4


t1 = Tree.Node 3 Tree.Leaf Tree.Leaf
t2 = Tree.Node 4 Tree.Leaf Tree.Leaf
t3 = Tree.Node 2 Tree.Leaf Tree.Leaf
t4 = foldr mappend Tree.Leaf [t1, t2, t3]

instance Ord a => Monoid (Tree.Tree a) where
	mempty = Tree.Leaf
	mappend Tree.Leaf t = t
	mappend t Tree.Leaf = t
	mappend t (Tree.Node val l r) = Tree.insert (mappend (mappend t l) r) val
	mconcat tlist = foldl mappend Tree.Leaf tlist 

instance Foldable Tree.Tree where
	foldr f neutral Tree.Leaf = neutral
	foldr f neutral (Tree.Node val Tree.Leaf Tree.Leaf) = f val neutral 
	foldr f neutral (Tree.Node val l r) = foldr f (f val (foldr f neutral r)) l


class Set t a where
    emptySet :: t a
    toList   :: t a -> [a]
    find     :: t a -> a -> t a
    insert   :: t a -> a -> t a
    delete   :: t a -> a -> t a
    next     :: t a -> a -> Maybe a
    fromList :: [a] -> t a

instance (Ord a, Foldable Tree.Tree, Monoid (Tree.Tree a)) => Set Tree.Tree a where
	emptySet = Tree.Leaf
	toList = foldr (:) []
	find  = Tree.find
	insert  = Tree.insert
	delete  = Tree.delete
	next    = Tree.next
	fromList = foldr (flip Tree.insert) Tree.Leaf