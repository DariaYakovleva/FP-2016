{-# OPTIONS_GHC -fno-warn-tabs #-}

import Tree2
main = do
	print $ "f"

class Set a where
    emptySet :: a
    toList   :: a -> [b]
    find     :: a -> b -> a
    insert   :: a -> b -> a
    delete   :: a -> b -> a
    next     :: a -> a
    fromList :: [b] -> a

instance (Foldable Tree, Monoid (Tree a)) => Set (Tree a) where
	emptySet = Leaf
    --toList   = undefined
    --find     = undefined
    --insert   = undefined
    --delete   = undefined
    --next     = undefined
    --fromList = undefined