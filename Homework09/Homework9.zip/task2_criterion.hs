--TASK
--Compare your implementation of mutable ST array with other implementations 
--(List, DList, Data.Sequence, smth else) using criterion package.
--Think about how this implementations could be compared in the most honest way.

import Criterion.Main
import Data.List
import Data.Sequence
import Control.Monad.ST
import Control.Monad
import Data.STRef
import Data.Array.ST
import MyArray

main = defaultMain [
  bgroup "lists" [ bench "MyArray" $ whnf pushToMyArray 1000
  				 , bench "List"  $ whnf pushToList 1000
  				 , bench "Sequence"  $ whnf pushToSeq 1000
               ]
  ]	

--main :: IO ()
--main = do
--	putStrLn $ "HW9.2"
--	print $ pushToList 100

myA :: ST s (MyArray s Int)
myA = newMyArray

pushToMyArray :: Int -> ()
pushToMyArray n = runST $ pushToMyArray' n

pushToMyArray' :: Int -> ST s ()
pushToMyArray' 0 = return ()
pushToMyArray' n = do 
	mm <- myA
	pushBack mm n
	pushToMyArray' (n - 1)

pushToList :: Int -> [Int]
pushToList 0 = []
pushToList n = (pushToList (n - 1)) ++ [n]

pushToSeq :: Int -> Seq Int
pushToSeq 0 = empty
pushToSeq n = (pushToSeq (n - 1)) |> n

-- find elem with index x

findXinMyArray :: MyArray s Int -> Int -> ST s Int
findXinMyArray lst ind = getElement lst ind


-- popBack a lot of time
