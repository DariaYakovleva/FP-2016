# Authors

The following people have contributed to Megaparsec/Parsec library. Due to
the fact that original Parsec project has not been keeping this sort of
file, many contributors are missing from this list, if you've contributed to
Parsec project in the past, please open an issue or a pull request, so we
can add you to this list.

Names below are sorted alphabetically.

## Author of original Parsec library

* Daan Leijen

## Maintainer

* Mark Karpov

## Retired maintainers

* Antoine Latter
* Derek Elkins

## Contributors

* Albert Netymk
* Antoine Latter
* Artyom (@neongreen)
* Auke Booij
* Ben Pence
* Benjamin Kästner
* Björn Buckwalter
* Bryan O'Sullivan
* Cies Breijs
* Daniel Díaz
* Daniel Gorín
* Dennis Gosnell
* Derek Elkins
* Emil Sköldberg
* Herbert Valerio Riedel
* Joel Williamson
* Mark Karpov
* Paolo Martini
* redneb
* Reto Kramer
* Rogan Creswick
* Roman Cheplyaka
* Ryan Scott
* Simon Vandel
* Slava Shklyaev
* Tal Walter
