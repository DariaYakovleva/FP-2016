--"1. Полное соблюдение стайл-гайда в рамках известного вам.
--2. Если требуется использовать какую-то коллекцию (мапа), то необходимо использовать библиотеки, а не свои
--(по возможности этот пункт применяется и к другим библиотекам)
--3. Запрещается использовать do-нотацию вне IO."

{-# OPTIONS_GHC -Wall #-}
{-# OPTIONS_GHC -fno-warn-tabs #-}
{-# LANGUAGE FlexibleInstances, UndecidableInstances #-}
--import Prelude hiding (Monad, (>>=), return)
main :: IO()
main = do
	print $ "HW4.4"

newtype State s a = State {runState :: s -> (a, s)}

--class Monad m where   -- m :: * -> *
--    return :: a -> m a                  -- return
--    (>>=)  :: m a -> (a -> m b) -> m b  -- bind

--State type is wrapper for function that takes some «state» and returns 
--pair of «value» (result, state outcome) and «new state».
--return must create State from function that doesn't change «state» and returns given «value».
--bind applies function to «value», feeds old «state» and returns new «state» with new «value».

instance (Applicative (State s)) => Monad (State s) where
	return a = State $ \s -> (a, s)
	curState >>= f = State $ \s -> let (curA, curS) = runState curState s in runState (f curA) curS
	
