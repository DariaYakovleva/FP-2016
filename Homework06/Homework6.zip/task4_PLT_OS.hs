--Implement CPS-transformed view of operating system with small subset of system calls using Cont monad. 
--You can find guide and theory here.
--Support next system calls: read, write, exit, yield, fork.
--It should be possible to write such monadic code which will be interpreted by kernel:

{-# OPTIONS_GHC -Wall #-}
{-# OPTIONS_GHC -fno-warn-tabs #-}
--{-# LANGUAGE FlexibleInstances, FlexibleContexts, UndecidableInstances, OverlappingInstances #-}

import Control.Monad.Cont

main :: IO()
main = do
	print $ "HW6.4"	

--newtype Cont r a = Cont { runCont :: (a -> r) -> r }